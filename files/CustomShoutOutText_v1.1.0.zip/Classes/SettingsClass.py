import os
import codecs
import json

class Settings(object):
	""" Load in saved settings file if available else set default values. """
	def __init__(self, settingsFile=None):
		try:
			with codecs.open(settingsFile, encoding="utf-8-sig", mode="r") as f:
				self.__dict__ = json.load(f, encoding="utf-8")
		except:
			self.autoShoutOut = True
			self.shoutOutOnJoin = False
			self.autoShoutRaiders = False
			self.shoutRaiderMessage = "Hey, peeps! We just got raided by {raider} with other {count} viewers! Visit {url} and follow this person, so you can watch gameplays of {game}!"
			self.minRaidersToShout = 1
			self.addRaidersToCaster = True
			self.manualShoutCommand = "!caster"
			self.shoutPerms = "Moderator"
			self.allowShoutUnsaved = True
			self.defaultShoutOutMsg = "If you don't know {caster} yet, please drop them a follow at their channel at {url} so you can watch cool gameplays of {game}!"
			self.globalCoolDown = 5
			self.addCasterCmd = "!addcaster"
			self.edtCasterCmd = "!setcaster"
			self.delCasterCmd = "!delcaster"
			self.chkCasterCmd = "!chkcaster"
			self.delAllCasters = False
			self.createBackup = True
			self.printLog = False
			self.autoLog = True

	def Reload(self, jsondata):
		""" Reload settings from AnkhBot user interface by given json data. """
		self.__dict__ = json.loads(jsondata, encoding="utf-8")
		return

	def Save(self, settingsFile):
		""" Save settings contained within to .json and .js settings files. """
		try:
			with codecs.open(settingsFile, encoding="utf-8-sig", mode="w+") as f:
				json.dump(self.__dict__, f, encoding="utf-8", ensure_ascii=False, indent=2, sort_keys=True)
			with codecs.open(settingsFile.replace("json", "js"), encoding="utf-8-sig", mode="w+") as f:
				f.write("var settings = {0};".format(json.dumps(self.__dict__, encoding='utf-8')))
		except:
			Parent.Log("ERROR: ", "[" + ScriptName + "]: The settings file could not be saved! (Settings)")
		return
