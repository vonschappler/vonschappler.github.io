#---------------------------------------
# Import Libraries
#---------------------------------------
import sys
import os
import codecs
import json
import time
import collections
sys.path.append(os.path.join(os.path.dirname(__file__), "Classes"))
import clr
clr.AddReference("IronPython.SQLite.dll")
clr.AddReference("IronPython.Modules.dll")
from SettingsClass import Settings

#---------------------------------------
# Script Information
#---------------------------------------
ScriptName = "Multi-Streaming Utility"
Website = "https://rebrand.ly/vonWebsite "
Description = "Multi-streaming utility for your stream."
Creator = "von_Schappler"
Version = "1.0.3"

#---------------------------------------
# Variables
#---------------------------------------
global settingsFile
settingsFile = os.path.join(os.path.dirname(__file__), "settings.json")
global scriptSettings
scriptSettings = Settings(settingsFile)
global casterName, dispName, url, friends, game, multiMsgToSend, isEnabled, directory,logDir
global logFileName, gameToShow, gameSet

isEnabled = True
setMultiOn = "!setmultion"
setmultioff = "!setmultioff"
setMultiGame = "!setmultigame"
multiDisplay = "!multi"
multiMsg = "/me {caster} is currently multi-streaming with {friends} at {link} ! Click the link to a multi-view of {game}!"
multiGame = ""
multiUserCD = 5.0
multiAutoMsg = True
multiAutoCD = 10
multiProvider = "multitwitch.live"
printLog = False
autoLog = True
friends = ""
url = ""
multiMsgToSend = ""
logDir = os.path.join(os.path.dirname(__file__), "Log")
logFileName = "MultiStreamLog_"
gameToShow = ""
gameSet = False

#---------------------------------------
# Initialize Data on Load
#---------------------------------------
def Init():
	global logDir

	logDir = os.path.join(os.path.dirname(__file__), "Log")
	'''Could not understand why the compiler wanted me to put idented like that...'''
    	if not os.path.exists(logDir):
        	os.makedirs(logDir)
	try:
		with codecs.open(os.path.join(os.path.dirname(__file__), "settings.json"), encoding="utf-8-sig", mode="r") as file:
			ReloadSettings(file.read())
	except:
		Parent.Log("Error: ", time.strftime("(%Y/%m/%d - %H:%M:%S) ") + ScriptName + ": Unable to load settings during execution! (Init)")
	return

#---------------------------
#   [Optional] Reload Settings (Called when a user clicks the Save Settings button in the Chatbot UI)
#---------------------------
def ReloadSettings(jsondata):
	global logFileName, logMessage
	setMultiOn = scriptSettings.setMultiOn
	setMultiOff = scriptSettings.setMultiOff
	setmMultiGame = scriptSettings.setMultiGame
	multiDisplay = scriptSettings.multiDisplay
	multiMsg = scriptSettings.multiMsg
	multiGame = scriptSettings.multiGame
	multiUserCD = scriptSettings.multiUserCD
	multiAutoMsg = scriptSettings.multiAutoMsg
	multiAutoCD = scriptSettings.multiAutoCD
	multiProvider = scriptSettings.multiProvider
	printLog = scriptSettings.printLog
	autoLog = scriptSettings.autoLog
	logFileName += time.strftime("%Y%m%d_%H%M%S") + ".log"
	logMessage = "These is the begin of the file for " + ScriptName + " on " + time.strftime("%Y/%m/%d@%H%M%S") + ":\n"
	logMessage += "Below you have a list of last saved settings, updated just AFTER you press \"Save Settings\" button:\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "Settings - Message to sent in chat with Multi-Streaming link: " + str(multiMsg) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "Settings - Preferred Multi-Streaming provider: " + str(multiProvider) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "Settings - Game played during Multi-streaming: " + str(multiGame) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "Settings - Command to set link for Multi-Streaming: " + str(setMultiOn) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "Settings - Command to reset link for Multi-Streaming: " + str(setMultiOff) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "Settings - Command to set game manually: " + str(setMultiGame) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "Settings - Command to display Multi-Streaming link in chat: " + str(multiDisplay) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "Settings - User cooldown between uses of Multi-Streaming display command: " + str(multiUserCD) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "Settings - Allow the script to auto post Multi-Stream link: " + str(multiAutoMsg) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "Settings - Time between auto Multi-Streaming Messages: " + str(multiAutoCD) + "\n"
	logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "Settings - URL created for display in chat: " + str(multiMsgToSend) + "\n"
	if printLog == True:
		Parent.Log("Info: ", time.strftime("(%Y/%m/%d - %H:%M:%S) ") + ScriptName + " loaded settings:")
		Parent.Log("Settings: ", "Message to sent in chat with Multi-Streaming link: " + str(multiMsg))
		Parent.Log("Settings: ", "Preferred Multi-Streaming provider: " + str(multiProvider))
		Parent.Log("Settings: ", "Game played during Multi-streaming: " + str(multiGame))
		Parent.Log("Settings: ", "Command to set link for Multi-Streaming: " + str(setMultiOn))
		Parent.Log("Settings: ", "Command to reset link for Multi-Streaming: " + str(setMultiOff))
		Parent.Log("Settings: ", "Command to set game manually: " + str(setMultiGame))
		Parent.Log("Settings: ", "Command to display Multi-Streaming link in chat: " + str(multiDisplay))
		Parent.Log("Settings: ", "User cooldown between uses of Multi-Streaming display command: " + str(multiUserCD))
		Parent.Log("Settings: ", "Allow the script to auto post Multi-Stream link: " + str(multiAutoMsg))
		Parent.Log("Settings: ", "Time between auto Multi-Streaming Messages: " + str(multiAutoCD))
	return

def ScriptToggled(state):
    if not state:
        scriptSettings.Save(settingsFile)
    return

#---------------------------------------
#	Script is going to be unloaded
#---------------------------------------
def Unload():
	LogFile()
	return

#---------------------------------------
#	Script is enabled or disabled on UI
#---------------------------------------
def ScriptToggled(state):
	global scriptSettings, isEnabled
	if not state:
		scriptSettings.Save(settingsFile)
		isEnabled = False
	else:
		isEnabled = True
	return isEnabled

#---------------------------------------
# Execute data and process messages
#---------------------------------------
def Execute(data):
	if data.IsChatMessage() and isEnabled:
		if data.IsFromTwitch():
			source = "twitch"
			Multi(source, data.User.lower(), data.GetParam(0), data.Message[len(data.GetParam(0)) + len(" "):])
		if data.IsFromDiscord():
			source = "discord"
			Multi(source, data.User.lower(), data.GetParam(0), data.Message[len(data.GetParam(0)) + len(" "):])
	return

def GetKeyByIndex(dictionary, index):
	return

#---------------------------------------
# Tick
#---------------------------------------
def Tick():
	global logMessage
	multiAutoCD = scriptSettings.multiAutoCD
	multiAutoMsg = scriptSettings.multiAutoMsg
	if multiAutoMsg and not Parent.IsOnCooldown(ScriptName, "autoMulti") and multiMsgToSend !="":
		cd = scriptSettings.multiAutoCD * 60
		Parent.SendStreamMessage(multiMsgToSend)
		logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "Info - the multi-stream link was displayed in chat automatically.\n"
		Parent.AddCooldown(ScriptName, "autoMulti", cd)
	return

#---------------------------------------
# Functions
#---------------------------------------
def Multi(source, user, message, args):
	global selProvider, cooldown, command, casterName, url, friends, game, multiMsgToSend, logMessage, gameToShow, gameSet, newGame
	selProvider = scriptSettings.multiProvider
	coolDown = scriptSettings.multiUserCD * 60
	command = message
	setCommands = [scriptSettings.setMultiOn, scriptSettings.setMultiOff, scriptSettings.setMultiGame]
	showCommand = [scriptSettings.multiDisplay]
	casterName = Parent.GetChannelName().lower()
	toSend = scriptSettings.multiMsg
	source = source
	game = scriptSettings.multiGame
	if Parent.HasPermission(user, "Moderator", "") and command in setCommands:
		if bool(command == setCommands[0]) and not bool(args):
			friends = ""
			url = "http://" + selProvider + "/" + casterName + "/"
			multiMsgToSend = ""
			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "Error - " + user + " tried to create a URL multi-stream message with no success. (Error: Missing arguments)\n"
			Parent.SendStreamWhisper(user, "/me Fail to create multi-stream link. You missed the required info for creating the multi-stream link.")
		if bool(command == setCommands[1]):
			friends = ""
			url = "http://" + selProvider + "/" + casterName + "/"
			multiMsgToSend = ""
			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "Settings - " + user + " disabled the multi-stream link with success.\n"
			Parent.SendStreamWhisper(user, "/me Multi-stream is disabled. All friends erased...")
		if bool(command == setCommands[2]) and bool(args):
			if args == "auto":
				jsonData = json.loads(Parent.GetRequest("https://decapi.me/twitch/game/" + casterName,{}))
				newGame = jsonData["response"]
				gameToShow = newGame
				gameSet = True
			else:
				newGame = args
				gameToShow = newGame
				gameSet = True
			multiMsgToSend = scriptSettings.multiMsg.format(caster = casterName, link = url, friends = friends[:-1], game = gameToShow)
			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "Settings - "+ user + " has changed the game to: " + gameToShow + "\n"
			Parent.SendStreamWhisper(user, "/me Game was updated. Viewers can now type !multi in chat to display this link: " + url + " where you are playing " + gameToShow + "." )
		if bool(command == setCommands[2]) and not bool(args):
			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "Info - " + user + " tried to create change the game, but due to missing arguments, no changes were made for game.\n"
			Parent.SendStreamWhisper(user, "/me Fail to change the game, you need to enter the game name after the command.")
		if bool(command == setCommands[0]) and bool(args):
			friends = ""
			url = ""
			if gameSet == True:
				gameToShow = newGame
			else:
				if not bool(game):
					jsonData = json.loads(Parent.GetRequest("https://decapi.me/twitch/game/" + casterName,{}))
					game = jsonData["response"]
					gameToShow = game
					gameSet = False
				else:
					game = scriptSettings.multiGame
					gameToShow = game
					gameSet = False
			url = "http://" + selProvider + "/" + casterName + "/"
			args = args.split(" ")
			for name in args:
				friends += name + "/"
		 	url += friends
			multiMsgToSend = scriptSettings.multiMsg.format(caster = casterName, link = url, friends = friends[:-1], game = gameToShow)
			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "Info - " + user + " changes friends you are/were playing with to: " + str(friends) + "\n"
			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "Settings - "+ user + " has changed the URL to: " + str(url) + "\n"
			Parent.SendStreamWhisper(user, "/me Multi-stream link is set correctly. Viewers can now type !multi in chat to display this link: " + url + " where you are playing " + gameToShow + "." )
	if not Parent.HasPermission(user, "Moderator", "") and command in setCommands:
		logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "Error - " + user + " tried to create a URL multi-stream message with no success. (Error: Missing permision)\n"
		Parent.SendStreamWhisper(user, "/me You don't have the permission to do this!")
	if Parent.HasPermission(user, "Everyone", "") and command in showCommand:
		if Parent.IsOnUserCooldown(ScriptName, command, user):
			logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "Error - " + user + " tried to display the link in chat with no success. (Error: "+ user + " had colldown on command).\n"
			Parent.SendStreamWhisper(user, "/me " + user + ", " + command + " is under user cooldown for " + str(Parent.GetUserCooldownDuration(ScriptName, command, user)) + " seconds!")
		if not Parent.IsOnUserCooldown(ScriptName, command, user):
			if bool(friends):
				multiMsgToSend = scriptSettings.multiMsg.format(caster = casterName, link = url, friends = friends[:-1], game = gameToShow)
				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "Info - " + user + " displayed the link in chat.\n"
				Parent.SendStreamMessage(multiMsgToSend)
			if not bool(friends):
				multiMsgToSend = url
				logMessage += time.strftime("[%Y/%m/%d@%H:%M:%S] ") + "Error - " + user + " tried to display the link in chat with no success. (Error: No URL was set).\n"
				Parent.SendStreamMessage("/me " + casterName + " is not multi-streaming right now! Try again later...")
			if not Parent.HasPermission(user, "moderator", ""):
				Parent.AddUserCooldown(ScriptName, command, user, coolDown)
	return multiMsgToSend

def LogFile():
	global logMessage, logFileName, logDir
	logMessage += "This is the end of the SettingsLog file."
	location = os.path.join(os.getcwd(), logDir)
	try:
		f = open(location + "\\" + logFileName, "w+")
		f.write(logMessage)
		f.close()
		Parent.Log("Info:", ScriptName + ": Log file saved successfully!")
	except:
		Parent.Log("Error:", ScriptName + ": Unable to save Log file due to an unexpected error.")
		return
	return
#---------------------------------------
# SetDefaults Custom User Interface Button
#---------------------------------------
def ReadMeFile():
    location = os.path.join(os.path.dirname(__file__), "README.txt")
    os.startfile(location)

def ChangesFile():
    location = os.path.join(os.path.dirname(__file__), "CHANGES.txt")
    os.startfile(location)

def OpenLogDir():
	location = logDir
	os.startfile(os.path.join(os.getcwd(), logDir))

def OpenWebSite():
	os.startfile(Website)
