//For random messages.
var messages = [];
messages[0] = "Random message 1";
messages[1] = "Random message 2";
messages[2] = "Random message 3";